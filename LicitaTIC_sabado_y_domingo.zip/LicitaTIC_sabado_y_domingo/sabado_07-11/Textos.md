# Sábado 7/11/2026 · Contenido ligero

## Horario de hoy
- 13:30 · Carrusel «4 ideas para licitar mejor» (repaso de la semana) · Instagram, TikTok, Facebook, LinkedIn
- 16:30 · Imagen «Expectativa vs realidad: leer un pliego» (formato tendencia) · Instagram, TikTok, Facebook, LinkedIn
- 18:00 · Storie «¿Qué parte del pliego lees primero?» · Instagram y Facebook
- 20:00 · Reel «Licitar con cabeza · 01» · Instagram, TikTok, Facebook, LinkedIn (textos en Textos_reel.md)

## 13:30 · Carrusel · Instagram / TikTok (título TikTok: Repaso de la semana)
Repaso de la semana: 4 ideas para licitar mejor 📚

1️⃣ El DEUC es una declaración, no un certificado.
2️⃣ El precio: fórmula, umbral, mercado y costes. Por ese orden.
3️⃣ No siempre gana la más barata.
4️⃣ Una carpeta por sobre y el precio solo en el económico.

Guárdalo para tu próxima oferta 📌 ¿Qué tema quieres que tratemos la semana que viene? 👇

#LicitacionesTIC #ContrataciónPública #LicitacionesPúblicas #Pymes #SectorTIC

### Facebook
Por si te perdiste algo esta semana, aquí van 4 ideas para licitar mejor 📚

El DEUC es una declaración, no un certificado. El precio se decide con fórmula, umbral, mercado y costes. No siempre gana la más barata. Y una carpeta por sobre, con el precio solo en el económico.

¿Qué tema te gustaría que tratáramos la semana que viene? 👇

#LicitacionesTIC #ContrataciónPública

### LinkedIn (documento: «4 ideas para licitar mejor»)
Cuatro ideas de esta semana para preparar mejor una licitación pública:

1. El DEUC es una declaración responsable, no un certificado. Si la oferta resulta elegida, habrá que acreditarlo todo, normalmente en 10 días hábiles.
2. El precio se decide con contexto: fórmula del pliego, umbral de baja anormal, adjudicaciones comparables y costes propios.
3. No siempre gana la oferta más barata: se adjudica a la mejor relación calidad-precio.
4. Orden en la documentación: una carpeta por sobre y el precio solo en el sobre económico.

¿Qué tema os gustaría que tratáramos la próxima semana?

#ContrataciónPública #LicitacionesPúblicas #SectorTIC #Pymes

## 16:30 · Imagen «Expectativa vs realidad» · Instagram / TikTok (título TikTok: Expectativa vs realidad)
Expectativa: «me leo el pliego en una tarde» 😅
Realidad: PCAP, PPT, anexos y aclaraciones.

Truco: empieza por la solvencia, los criterios de adjudicación y los plazos. Con eso ya sabes si te interesa seguir leyendo.

¿Te ha pasado? 👇

#LicitacionesTIC #ContrataciónPública #Pymes #SectorTIC

### Facebook
«Me leo el pliego en una tarde»… y luego llegan el PCAP, el PPT, los anexos y las aclaraciones 😅

Un truco: empieza por la solvencia, los criterios de adjudicación y los plazos. Con eso ya sabes si merece la pena seguir.

#LicitacionesTIC #ContrataciónPública

### LinkedIn
Expectativa: «el pliego me lo leo en una tarde».
Realidad: PCAP, PPT, anexos y aclaraciones.

Una forma de ahorrar tiempo: empezar por tres apartados, la solvencia exigida, los criterios de adjudicación y los plazos. Si alguno no encaja, no hace falta leer el resto.

#ContrataciónPública #LicitacionesPúblicas #SectorTIC

## 18:00 · Storie · Instagram y Facebook
¿Qué parte del pliego lees primero? A) Los criterios de adjudicación B) La solvencia que piden C) El presupuesto y el plazo · Respóndenos por mensaje.

# Reel sábado 7/11 · 20:00 · Instagram, TikTok, Facebook y LinkedIn
Serie «Licitar con cabeza» · 01 · 19 s

## Instagram / Facebook
Antes de leerte 200 páginas de pliego, mira estas 3 cosas 👇

1️⃣ La solvencia: ¿puedes acreditar lo que piden?
2️⃣ El plazo: ¿te da tiempo a hacer una buena oferta?
3️⃣ El presupuesto: ¿te salen los números?

Si falla una, pasa a la siguiente. Elegir bien también es licitar.

Síguenos: cada día, una pista para licitar con cabeza 📌

#LicitacionesTIC #ContrataciónPública #LicitacionesPúblicas #Pymes

## TikTok (título: 3 cosas antes de leer un pliego)
Antes de leerte 200 páginas de pliego, mira esto 👀 Solvencia, plazo y presupuesto. Si falla una, a la siguiente. Síguenos para más pistas 📌 #licitaciones #contratacionpublica #pymes #licitacionespublicas

## LinkedIn
Antes de leer las 200 páginas de un pliego, conviene hacerse tres preguntas:

1. Solvencia: ¿podemos acreditar la facturación y los trabajos similares que se exigen?
2. Plazo: ¿hay tiempo para preparar una oferta sólida?
3. Presupuesto: ¿encaja el presupuesto base de licitación con nuestros costes?

Si una de las tres falla, lo más rentable suele ser pasar a la siguiente. Elegir bien a qué presentarse también forma parte de licitar.

#ContrataciónPública #LicitacionesPúblicas #SectorTIC #Pymes
