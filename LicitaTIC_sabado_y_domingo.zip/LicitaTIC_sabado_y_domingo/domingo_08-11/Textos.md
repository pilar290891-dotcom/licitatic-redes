# Domingo 08/11/2026 · Textos

## 13:30 · Carrusel «Glosario del domingo: 5 siglas» (IG, TikTok, FB, LinkedIn)
**Instagram**
Glosario del domingo: 5 siglas que verás en todo pliego 📚

PCAP · Pliego de Cláusulas Administrativas Particulares
PPT · Pliego de Prescripciones Técnicas
DEUC · Documento Europeo Único de Contratación
CPV · Vocabulario Común de Contratos Públicos
PBL · Presupuesto base de licitación

Guárdalo para tu próximo pliego 📌 ¿Qué otra sigla te trae de cabeza? Déjala en comentarios 👇

#LicitacionesTIC #ContrataciónPública #LicitacionesPúblicas #Pymes #SectorTIC

**TikTok** (título: Glosario del domingo)
5 siglas que verás en todo pliego 📚 PCAP, PPT, DEUC, CPV y PBL, explicadas sin rodeos. ¿Cuál añadirías? 👇 #licitaciones #contratacionpublica #pymes #licitacionespublicas

**Facebook**
Si alguna vez te has perdido entre siglas leyendo un pliego, esto es para ti 📚

PCAP, PPT, DEUC, CPV y PBL: qué significa cada una y para qué te sirve.

¿Hay alguna otra que te cueste? Cuéntanosla y la explicamos.

#LicitacionesTIC #ContrataciónPública

**LinkedIn** (documento PDF, título: 5 siglas que verás en todo pliego)
Cinco siglas que aparecen en casi cualquier licitación pública y conviene tener claras:

PCAP: las reglas del procedimiento (solvencia, criterios, plazos, presentación).
PPT: el contenido técnico del contrato, al que responde la memoria técnica.
DEUC: declaración responsable de cumplimiento; la acreditación llega después.
CPV: códigos que clasifican el objeto del contrato y sirven para buscar licitaciones.
PBL: el límite máximo de gasto, IVA incluido. Ninguna oferta puede superarlo.

¿Qué otra sigla añadiríais al glosario?

#ContrataciónPública #LicitacionesPúblicas #SectorTIC #Pymes

## 16:30 · Trend «Te debo una foto» (IG, TikTok, FB, LinkedIn)
**Instagram**
—¿Cómo preparas la semana de licitaciones?
—Te debo una foto 📸

Aquí está: licitaciones nuevas filtradas, plazos en el calendario con margen, certificado digital comprobado y dudas del pliego preguntadas con tiempo.

¿Qué añadirías tú a la foto? 👇

#LicitacionesTIC #ContrataciónPública #Pymes #SectorTIC

**TikTok** (título: Te debo una foto)
¿Cómo preparas la semana de licitaciones? Te debo una foto 📸 Licitaciones filtradas, plazos con margen, certificado en vigor y dudas preguntadas a tiempo. ¿Qué añadirías? 👇 #licitaciones #contratacionpublica #pymes

**Facebook**
Domingo por la tarde, buen momento para dejar lista la semana 📸

Cuatro cosas que ahorran sustos: filtrar las licitaciones nuevas por sector y zona, apuntar los plazos con margen, comprobar que el certificado digital está en vigor y preguntar las dudas del pliego con tiempo.

#LicitacionesTIC #ContrataciónPública

**LinkedIn**
Una rutina sencilla para empezar la semana con las licitaciones bajo control:

1. Revisar las licitaciones nuevas, filtradas por sector y zona.
2. Llevar los plazos de la semana al calendario, con margen.
3. Comprobar que el certificado digital está en vigor.
4. Enviar las dudas del pliego con tiempo suficiente para recibir respuesta.

¿Qué paso añadiríais?

#ContrataciónPública #LicitacionesPúblicas #SectorTIC

## 18:00 · Storie (IG, FB)
«¿Cuándo buscas licitaciones nuevas?» A Cada día, un rato · B Una vez por semana · C Cuando me llega un aviso.

# Reel 08/11 · Licitar con cabeza · 02 (20:00)

**Instagram (REEL) y Facebook (REEL)**
Tu oferta puede quedar fuera sin que nadie la lea ⏰

1️⃣ La plataforma va lenta el último día.
2️⃣ El certificado falla: caducado, mal instalado o en otro ordenador.
3️⃣ Falta una firma y ya no hay tiempo.

Envía con un día de margen. Fuera de plazo no hay oferta, por buena que sea.

Síguenos: cada día, una pista para licitar con cabeza 📌

#LicitacionesTIC #ContrataciónPública #LicitacionesPúblicas #Pymes

**TikTok** (título: Que no te pille el plazo)
Tu oferta puede quedar fuera sin que nadie la lea ⏰ Plataforma lenta, certificado que falla, firma que falta. Envía con un día de margen. Síguenos para más pistas 📌 #licitaciones #contratacionpublica #pymes #licitacionespublicas

**LinkedIn**
Una oferta presentada fuera de plazo no se valora, por buena que sea.

Los tres motivos más habituales de llegar tarde:
1. La plataforma de licitación se satura el último día.
2. El certificado digital falla: caducado, mal instalado o en otro equipo.
3. Falta una firma y ya no queda tiempo para corregirlo.

La solución es sencilla: dejar la oferta enviada con al menos un día de margen.

#ContrataciónPública #LicitacionesPúblicas #SectorTIC #Pymes
